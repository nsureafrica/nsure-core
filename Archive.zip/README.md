# nsure-core

Nsure Insurance Application

Run cluster.js on production and server.js on development
