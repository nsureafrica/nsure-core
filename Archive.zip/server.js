//@ts-check

require("./App")